import tkinter as tk
from tkinter import messagebox
import random

class RedBlueNimGame:
    def __init__(self, heaps, is_misere=False, against_computer=False):
        self.heaps = heaps
        self.is_misere = is_misere
        self.against_computer = against_computer
        self.current_player = 1  # Start with player 1

    def is_game_over(self):
        return all(r == 0 and b == 0 for r, b in self.heaps)

    def make_move(self, heap_index, color, count):
        if heap_index < 0 or heap_index >= len(self.heaps):
            return False, "Invalid heap index."
        if color not in ["red", "blue"]:
            return False, "Invalid color. Choose 'red' or 'blue'."
        if count <= 0:
            return False, "Invalid count. Must be greater than zero."

        r, b = self.heaps[heap_index]
        if color == "red":
            if count > r:
                return False, "Not enough red objects."
            self.heaps[heap_index] = (r - count, b)
        else:
            if count > b:
                return False, "Not enough blue objects."
            self.heaps[heap_index] = (r, b - count)
        return True, ""

    def computer_move(self):
        while True:
            heap_index = random.randint(0, len(self.heaps) - 1)
            color = random.choice(["red", "blue"])
            r, b = self.heaps[heap_index]
            if color == "red" and r > 0:
                count = random.randint(1, r)
                self.heaps[heap_index] = (r - count, b)
                return heap_index, color, count
            elif color == "blue" and b > 0:
                count = random.randint(1, b)
                self.heaps[heap_index] = (r, b - count)
                return heap_index, color, count

    def next_turn(self):
        if self.against_computer and self.current_player == 2:
            heap_index, color, count = self.computer_move()
            self.current_player = 1
            return heap_index, color, count
        else:
            self.current_player = 3 - self.current_player
            return None, None, None

class NimApp:
    def __init__(self, root, game):
        self.root = root
        self.game = game
        self.create_widgets()
        self.update_display()

    def create_widgets(self):
        self.heap_labels = []
        self.remove_entries = []
        self.color_vars = []
        for i, (r, b) in enumerate(self.game.heaps):
            label = tk.Label(self.root, text=f"Heap {i+1}: Red={r}, Blue={b}")
            label.grid(row=i, column=0, columnspan=2)
            self.heap_labels.append(label)

            color_var = tk.StringVar(value="red")
            self.color_vars.append(color_var)
            tk.Radiobutton(self.root, text="Red", variable=color_var, value="red").grid(row=i, column=2)
            tk.Radiobutton(self.root, text="Blue", variable=color_var, value="blue").grid(row=i, column=3)

            entry = tk.Entry(self.root)
            entry.grid(row=i, column=4)
            self.remove_entries.append(entry)

        self.move_button = tk.Button(self.root, text="Make Move", command=self.make_move)
        self.move_button.grid(row=len(self.game.heaps), column=0, columnspan=5)
        
        self.status_label = tk.Label(self.root, text="")
        self.status_label.grid(row=len(self.game.heaps) + 1, column=0, columnspan=5)

    def update_display(self):
        for i, (r, b) in enumerate(self.game.heaps):
            self.heap_labels[i].config(text=f"Heap {i+1}: Red={r}, Blue={b}")
        if self.game.is_game_over():
            if self.game.is_misere:
                winner = f"Player {3 - self.game.current_player} (misère)"
            else:
                winner = f"Player {self.game.current_player}"
            self.status_label.config(text=f"Game Over! {winner} wins!")
            self.move_button.config(state=tk.DISABLED)
        else:
            self.status_label.config(text=f"Player {self.game.current_player}'s turn")

    def make_move(self):
        for i, entry in enumerate(self.remove_entries):
            count = entry.get()
            color = self.color_vars[i].get()
            if count.isdigit():
                count = int(count)
                valid, msg = self.game.make_move(i, color, count)
                if valid:
                    self.game.next_turn()
                    self.update_display()
                    if self.game.against_computer and self.game.current_player == 2:
                        heap_index, color, count = self.game.next_turn()
                        self.update_display()
                    return
                else:
                    messagebox.showerror("Invalid Move", msg)
                    return

if __name__ == "__main__":
    # Define the initial heaps
    heaps = [(3, 5), (2, 2), (7, 1)]  # Example heaps: (red, blue) counts

    # Create the root window
    root = tk.Tk()
    root.title("Red-Blue Nim Game")

    # Create the game settings window
    def start_game():
        mode = mode_var.get()
        opponent = opponent_var.get()

        is_misere = (mode == "misere")
        against_computer = (opponent == "yes")

        game = RedBlueNimGame(heaps, is_misere, against_computer)

        for widget in root.winfo_children():
            widget.destroy()

        app = NimApp(root, game)
    
    mode_var = tk.StringVar(value="standard")
    opponent_var = tk.StringVar(value="no")

    tk.Label(root, text="Choose game mode:").grid(row=0, column=0, columnspan=2)
    tk.Radiobutton(root, text="Standard", variable=mode_var, value="standard").grid(row=1, column=0)
    tk.Radiobutton(root, text="Misère", variable=mode_var, value="misere").grid(row=1, column=1)

    tk.Label(root, text="Play against computer?").grid(row=2, column=0, columnspan=2)
    tk.Radiobutton(root, text="Yes", variable=opponent_var, value="yes").grid(row=3, column=0)
    tk.Radiobutton(root, text="No", variable=opponent_var, value="no").grid(row=3, column=1)

    tk.Button(root, text="Start Game", command=start_game).grid(row=4, column=0, columnspan=2)

    root.mainloop()
